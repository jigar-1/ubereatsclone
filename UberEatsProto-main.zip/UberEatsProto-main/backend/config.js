const config = {
    url: '',
    secret: ''
};

module.exports = config;