export const ADD_TO_CART = 'ADD_TO_CART';
export const REMOVE_FROM_CART = 'REMOVE_FROM_CART';
export const DELETE_ITEM = 'DELETE_ITEM';
export const CLEAR_CART = 'CLEAR _CART';

export const SET_CURRENT_REST = 'SET_CURRENT_REST'
export const SET_NEW_REST = 'SET_NEW_REST'

export const SET_NEW_ORDER_ITEM = 'SET_NEW_ORDER_ITEM'
export const SET_ORDER_MODE = 'SET_ORDER_MODE'
export const MODAL_TOGGLE = 'MODAL_TOGGLE'


