const API_BASE_URL = "";

export const ACCESS_KEY_ID = "";
export const ACCESS_SECRET_KEY_ID = "";


export default API_BASE_URL