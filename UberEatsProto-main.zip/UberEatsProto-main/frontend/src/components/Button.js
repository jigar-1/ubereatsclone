import React from 'react'

const Button = () => {
    const updateDetails = () => {

    }
    return (
        <div>
            <button type="button" class="btn btn-primary btn-lg" onClick={updateDetails}>Update Details</button>
        </div>
    )
}

export default Button
